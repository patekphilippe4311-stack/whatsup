// Offline smoke test: fake Shopify Admin API + signed app-proxy requests.
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';

const SECRET = 'test-secret';
const state = { products: [], variants: [], tokens: 0, creates: 0 };
let nextId = 1;

const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    res.setHeader('Content-Type', 'application/json');
    if (req.url === '/admin/oauth/access_token') {
      state.tokens++;
      return res.end(JSON.stringify({ access_token: 'tok', scope: 'x', expires_in: 86399 }));
    }
    const { query, variables: v } = JSON.parse(body);
    const out = (data) => res.end(JSON.stringify({ data }));
    if (query.includes('publications(')) return out({ publications: { nodes: [{ id: 'gid://shopify/Publication/1', name: 'Online Store' }] } });
    if (query.includes('featuredMedia')) return out({ products: { nodes: [{ featuredMedia: { image: { url: 'https://img/x.png' } } }] } });
    if (query.includes('productCreate')) {
      const id = `gid://shopify/Product/${nextId++}`;
      const vid = `gid://shopify/ProductVariant/${nextId++}`;
      assert.equal(v.product.giftCard, true);
      state.products.push({ id, handle: v.product.handle });
      state.variants.push({ id: vid, pid: id, title: v.product.productOptions[0].values[0].name, sku: '', price: '0.00' });
      return out({ productCreate: { product: { id, variants: { nodes: [{ id: vid }] } }, userErrors: [] } });
    }
    if (query.includes('productVariantsBulkUpdate')) {
      const x = v.v[0];
      const row = state.variants.find((r) => r.id === x.id);
      row.price = x.price; row.sku = x.inventoryItem.sku;
      return out({ productVariantsBulkUpdate: { productVariants: [{ id: x.id }], userErrors: [] } });
    }
    if (query.includes('productVariantsBulkCreate')) {
      state.creates++;
      const x = v.v[0];
      const id = `gid://shopify/ProductVariant/${nextId++}`;
      state.variants.push({ id, pid: v.pid, title: x.optionValues[0].name, sku: x.inventoryItem.sku, price: x.price });
      return out({ productVariantsBulkCreate: { productVariants: [{ id }], userErrors: [] } });
    }
    if (query.includes('publishablePublish')) return out({ publishablePublish: { userErrors: [] } });
    if (query.includes('productVariants(')) {
      const m = /sku:(\S+)/.exec(v.q);
      const row = state.variants.find((r) => r.sku === m[1]);
      return out({ productVariants: { nodes: row ? [{ id: row.id }] : [] } });
    }
    if (query.includes('products(')) {
      const p = state.products.find((x) => v.q.includes(x.handle));
      return out({ products: { nodes: p ? [{ id: p.id, handle: p.handle, options: [{ name: 'Amount' }],
        variants: { nodes: state.variants.filter((r) => r.pid === p.id).slice(0, 1) } }] : [] } });
    }
    res.statusCode = 500; res.end('{}');
  });
});
await new Promise((r) => fake.listen(0, r));

process.env.SHOPIFY_SHOP = 'test.myshopify.com';
process.env.SHOPIFY_CLIENT_ID = 'id';
process.env.SHOPIFY_CLIENT_SECRET = SECRET;
process.env.ADMIN_BASE_URL = `http://127.0.0.1:${fake.address().port}`;
process.env.MAX_NEW_PER_HOUR = '3';
const { app } = await import('../server.js');
const srv = await new Promise((r) => { const s = app.listen(0, () => r(s)); });
const base = `http://127.0.0.1:${srv.address().port}`;

function signed(params) {
  const msg = Object.entries({ shop: 'test.myshopify.com', path_prefix: '/apps/se-gift', timestamp: '1', logged_in_customer_id: '', ...params })
    .map(([k, v]) => `${k}=${v}`).sort().join('');
  const signature = crypto.createHmac('sha256', SECRET).update(msg).digest('hex');
  return new URLSearchParams({ shop: 'test.myshopify.com', path_prefix: '/apps/se-gift', timestamp: '1', logged_in_customer_id: '', ...params, signature }).toString();
}
const get = async (qs) => { const r = await fetch(`${base}/proxy/amount?${qs}`); return [r.status, await r.json()]; };

// signature
assert.equal((await get('amount=189'))[0], 401, 'unsigned rejected');
assert.equal((await get(signed({ amount: '189' }) + 'x'))[0], 401, 'tampered rejected');
// validation
assert.equal((await get(signed({ amount: '99' })))[0], 400, 'below min');
assert.equal((await get(signed({ amount: '20001' })))[0], 400, 'above max');
assert.equal((await get(signed({ amount: '12.5' })))[0], 400, 'decimals rejected');
assert.equal((await get(signed({ amount: '1e3' })))[0], 400, 'exponent rejected');
// create + reuse (concurrent requests must create exactly one variant)
const [a, b] = await Promise.all([get(signed({ amount: '189' })), get(signed({ amount: '189' }))]);
assert.equal(a[0], 200); assert.equal(a[1].variantId, b[1].variantId);
assert.equal(state.creates, 1, 'one create for concurrent same amount');
const again = await get(signed({ amount: '189' }));
assert.equal(again[1].variantId, a[1].variantId); assert.equal(state.creates, 1, 'reused');
// seed variant ($100) was priced
const seed = state.variants.find((r) => r.title === '$100');
assert.equal(seed.price, '100.00'); assert.equal(seed.sku, 'GC-100');
assert.equal(state.products.length, 1, 'single product');
// hourly cap on NEW amounts (3 allowed: 189 used 1)
assert.equal((await get(signed({ amount: '250' })))[0], 200);
assert.equal((await get(signed({ amount: '300' })))[0], 200);
assert.equal((await get(signed({ amount: '350' })))[0], 429, 'cap hit');
assert.equal((await get(signed({ amount: '189' })))[0], 200, 'existing still served');
assert.equal(state.tokens, 1, 'token cached');
console.log('all smoke tests passed');
srv.close(); fake.close();
