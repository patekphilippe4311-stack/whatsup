# Swiss Emporium – Custom Gift Card Amounts

Lets customers type **any whole-dollar amount ($100–$20,000)** on the gift card page, pay at normal checkout, and receive a real Shopify gift card by email – no enquiry needed.

## How it works

```
Gift card page ──GET /apps/se-gift/amount?amount=189──▶ Shopify app proxy (signs the request)
                                                          │
                                                          ▼
                                              this server (Node, server.js)
                                              • verifies the signature
                                              • finds/creates a variant "$189" on a hidden
                                                "gift card" product (Admin GraphQL API)
                                              • returns { variantId }
Gift card page ◀──────────────────────────────────────────┘
   └─ POST /cart/add.js (that variant) → /cart → checkout
Shopify issues + emails the gift card automatically after payment (it is a gift card product).
```

If the app is ever down or errors, the page falls back to the old "request this amount" enquiry form.

## What you need
* Shopify plan that supports gift cards (Basic or higher) and owner/staff access to the store.
* A free Shopify **Dev Dashboard** login (dev.shopify.com) – use the same login that owns the store.
* A GitHub account and a host for the server (steps use Render; Fly.io / Railway work too).
  Free hosting plans sleep when idle, so the first custom amount after a quiet spell can take 30–60 s. Use a paid always-on plan (~US$7/mo).

---

## Step-by-step setup

### 1. Create the app (Dev Dashboard)
1. Go to **dev.shopify.com/dashboard** → **Create app** → name it `Swiss Emporium Custom Gift Cards`.
2. Open the app → **Settings** → copy the **Client ID** and **Client secret** (keep the secret private).
   *Do not release a version yet – you need your server URL first.*

### 2. Put the code on GitHub
**Important:** `package.json` and `server.js` must sit at the very top of the repo (not inside a folder), or Render fails with `Could not read package.json ... /opt/render/project/src/package.json`.
Website upload: unzip, open the unzipped folder, select everything *inside* it and drag it onto GitHub's *Add file → Upload files* page. Or use the terminal commands below.

1. Unzip this project. In a terminal inside the folder:
   ```
   git init && git add . && git commit -m "custom gift cards app"
   ```
2. Create a **private** repo on GitHub and push (`git remote add origin … && git push -u origin main`).

### 3. Deploy the server (Render)
1. render.com → **New → Web Service** → connect the GitHub repo.
2. Runtime **Node**, build command `npm install`, start command `npm start`, instance type **Starter** (always on).
3. Add environment variables:

   | Key | Value |
   |---|---|
   | `SHOPIFY_SHOP` | `your-store.myshopify.com` (Shopify admin → Settings → Domains shows it; **not** swissemporium.com.au) |
   | `SHOPIFY_CLIENT_ID` | from step 1 |
   | `SHOPIFY_CLIENT_SECRET` | from step 1 |

   Other settings (`MIN_AMOUNT`, `MAX_AMOUNT`, …) are in `.env.example` and have sensible defaults.
4. Deploy. Open `https://YOUR-APP.onrender.com/health` – it should say `ok`. Note this URL.

### 4. Configure and release the app version
Dev Dashboard → your app → **Versions → Create version**:
1. **App URL:** `https://YOUR-APP.onrender.com`  ·  untick *Embed app in Shopify admin*.
2. **Access scopes:** `write_products, write_publications, read_publications`.
3. **App proxy:** prefix `apps`, subpath `se-gift`, proxy URL `https://YOUR-APP.onrender.com/proxy`.
   (The theme calls `/apps/se-gift/amount`; if you choose another subpath, change `PROXY_URL` in the theme too.)
4. **Release** the version.

### 5. Install the app on the store
Dev Dashboard → your app → **Home → Install app** → pick your store → approve the permissions.

### 6. Upload the updated theme
Upload `swissemporium-theme-custom-gift-cards.zip` (Online Store → Themes → Add theme → Upload zip). **Preview it – don't publish yet.**

### 7. Test (preview theme)
1. Open `/products/gift-card` in the preview, click **Custom**, type `189`. The button should say **Add to cart** and the hint "Any amount checks out instantly".
2. Click it. You should land on the cart with *Swiss Emporium E-Gift Card – $189*. The first request creates the hidden product and can take a few seconds.
3. In Shopify admin → **Products** you'll now see **Swiss Emporium E-Gift Card** (type *Gift Card*, tag `se-custom-gift`). Check it shows an image; if not, upload one.
4. Place a test order (turn on Bogus Gateway on a dev store, or place a real order and refund it). Confirm a gift card appears under **Products → Gift cards** and the customer email arrives.
5. Try an amount below $100 / above $20,000 – these should not add to cart (below the minimum nothing is added; above the maximum you're sent to the enquiry form).

### 8. Go live
Publish the theme. Done.

---

## Day-to-day notes
* New amounts are created on first use and reused afterwards (SKU `GC-189`). A product can hold up to 2,048 variants; the app also limits new amounts to 20/hour (`MAX_NEW_PER_HOUR`) to stop bots filling it up.
* The helper product is hidden from collections/search by the theme (tag `se-custom-gift`) and from search engines (`seo.hidden`). Don't delete it; don't change its tag.
* Change min/max in the server env vars **and** `MIN_CUSTOM` / `MAX_CUSTOM` at the top of the script in `snippets/vela-prodetail-info.liquid`.
* Logs: Render → your service → Logs.

## Troubleshooting
| Symptom | Fix |
|---|---|
| Custom amount falls back to the enquiry form | Open `https://your-store.com/apps/se-gift/amount?amount=150` in the browser. A 404 page means the app proxy isn't configured/released or the app isn't installed. `{"error":"invalid_signature"}` is the *expected* reply to a manual call and means the proxy is working. Anything else: check the Render logs for the real error. |
| Logs say `shop_not_permitted` | The store isn't in the same Shopify organization as the app. Set `ENABLE_INSTALL_ROUTES=true` and `APP_URL=https://YOUR-APP.onrender.com`, add `https://YOUR-APP.onrender.com/auth/callback` to the app's redirect URLs, release, then visit `https://YOUR-APP.onrender.com/install`. Approve, copy the `SHOPIFY_ACCESS_TOKEN=…` shown into Render's env vars, set `ENABLE_INSTALL_ROUTES=false`, redeploy. (You may need to use *Distribution → Custom distribution* on the app first.) |
| Logs say `Could not find the Online Store sales channel` / publish error | Make sure the `write_publications` scope was in the released version and the app was re-installed after adding it. |
| Variant created but cart says it's unavailable | In admin, open the helper product and confirm it's *Active* and available on the **Online Store** channel. |
| `productCreate: ... gift card` error | Your plan may not support gift cards; or create the product by hand (Products → Gift cards → Add gift card product, handle `custom-e-gift-card`, option name `Amount`, tag `se-custom-gift`) and the app will use it. |

## Developing locally
```
npm install
npm test        # offline smoke test with a fake Shopify API
```
