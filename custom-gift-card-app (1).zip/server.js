// Swiss Emporium - custom gift card amounts.
//
// How it works
//   1. The gift card page calls  GET /apps/se-gift/amount?amount=189  (a Shopify app proxy).
//   2. Shopify forwards it here, signed. We verify the signature.
//   3. We make sure a hidden "gift card" product exists and has a variant priced at that amount
//      (created on demand, reused afterwards), and return its variant id.
//   4. The theme adds that variant to the cart. Because the product is a Shopify gift card
//      product, Shopify issues and emails the real gift card automatically after payment.
import express from 'express';
import crypto from 'node:crypto';

const env = process.env;
const int = (v, d) => (Number.isFinite(parseInt(v, 10)) ? parseInt(v, 10) : d);

export const cfg = {
  shop: (env.SHOPIFY_SHOP || '').replace(/^https?:\/\//, '').replace(/\/+$/, ''),
  clientId: env.SHOPIFY_CLIENT_ID || '',
  clientSecret: env.SHOPIFY_CLIENT_SECRET || '',
  staticToken: env.SHOPIFY_ACCESS_TOKEN || '',
  apiVersion: env.SHOPIFY_API_VERSION || '2026-04',
  min: int(env.MIN_AMOUNT, 100),
  max: int(env.MAX_AMOUNT, 20000),
  maxNewPerHour: int(env.MAX_NEW_PER_HOUR, 20),
  handle: env.CUSTOM_PRODUCT_HANDLE || 'custom-e-gift-card',
  title: env.CUSTOM_PRODUCT_TITLE || 'Swiss Emporium E-Gift Card',
  imageSourceHandle: env.IMAGE_SOURCE_HANDLE || 'gift-card',
  appUrl: (env.APP_URL || '').replace(/\/+$/, ''),
  installRoutes: env.ENABLE_INSTALL_ROUTES === 'true',
  adminBase: env.ADMIN_BASE_URL || '', // tests only
  scopes: 'write_products,write_publications,read_publications',
  optionName: 'Amount',
  skuPrefix: 'GC-',
  tag: 'se-custom-gift',
};

const log = (...a) => console.log(new Date().toISOString(), ...a);
const adminOrigin = () => cfg.adminBase || `https://${cfg.shop}`;

// ---------------------------------------------------------------------------
// Shopify Admin API client
// ---------------------------------------------------------------------------
let token = { value: cfg.staticToken, expires: cfg.staticToken ? Infinity : 0 };

async function getToken(force = false) {
  if (cfg.staticToken) return cfg.staticToken;
  if (!force && token.value && Date.now() < token.expires - 60_000) return token.value;
  const res = await fetch(`${adminOrigin()}/admin/oauth/access_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
    }),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.access_token) {
    throw new Error(`Token request failed (${res.status}): ${JSON.stringify(body)}`);
  }
  token = { value: body.access_token, expires: Date.now() + (body.expires_in || 86399) * 1000 };
  return token.value;
}

async function gql(query, variables = {}, attempt = 0, refresh = false) {
  const res = await fetch(`${adminOrigin()}/admin/api/${cfg.apiVersion}/graphql.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Shopify-Access-Token': await getToken(refresh) },
    body: JSON.stringify({ query, variables }),
  });
  if (res.status === 401 && !refresh && !cfg.staticToken) {
    return gql(query, variables, attempt, true); // token expired early: fetch a fresh one once
  }
  if (res.status === 429 && attempt < 3) {
    await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
    return gql(query, variables, attempt + 1);
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Admin API ${res.status}: ${JSON.stringify(body)}`);
  if (body.errors) {
    const throttled = JSON.stringify(body.errors).includes('THROTTLED');
    if (throttled && attempt < 3) {
      await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
      return gql(query, variables, attempt + 1);
    }
    throw new Error(`GraphQL errors: ${JSON.stringify(body.errors)}`);
  }
  return body.data;
}

function assertNoUserErrors(label, payload) {
  const errs = payload?.userErrors || [];
  if (errs.length) throw new Error(`${label}: ${errs.map((e) => e.message).join('; ')}`);
}

const numericId = (gid) => String(gid).split('/').pop();
const label = (amount) => `$${amount}`;
const skuFor = (amount) => `${cfg.skuPrefix}${amount}`;

// ---------------------------------------------------------------------------
// Hidden gift card product + variants
// ---------------------------------------------------------------------------
const VARIANT_FIELDS = 'id title sku price';

async function findProduct() {
  const d = await gql(
    `query($q:String!){ products(first:1, query:$q){ nodes{
        id handle options{ name }
        variants(first:1){ nodes{ ${VARIANT_FIELDS} } } } } }`,
    { q: `handle:${cfg.handle}` },
  );
  return d.products.nodes[0] || null;
}

async function onlineStorePublicationId() {
  const d = await gql(`{ publications(first:25){ nodes{ id name } } }`);
  const p = d.publications.nodes.find((n) => n.name === 'Online Store');
  if (!p) throw new Error('Could not find the Online Store sales channel');
  return p.id;
}

async function sourceImageUrl() {
  try {
    const d = await gql(
      `query($q:String!){ products(first:1, query:$q){ nodes{
         featuredMedia{ ... on MediaImage{ image{ url } } } } } }`,
      { q: `handle:${cfg.imageSourceHandle}` },
    );
    return d.products.nodes[0]?.featuredMedia?.image?.url || null;
  } catch (e) {
    log('image lookup skipped:', e.message);
    return null;
  }
}

async function configureVariant(productId, variantId, amount) {
  const d = await gql(
    `mutation($pid:ID!, $v:[ProductVariantsBulkInput!]!){
       productVariantsBulkUpdate(productId:$pid, variants:$v){
         productVariants{ id } userErrors{ field message } } }`,
    {
      pid: productId,
      v: [{
        id: variantId,
        price: `${amount}.00`,
        taxable: false,
        inventoryPolicy: 'CONTINUE',
        inventoryItem: { sku: skuFor(amount), tracked: false, requiresShipping: false },
      }],
    },
  );
  assertNoUserErrors('productVariantsBulkUpdate', d.productVariantsBulkUpdate);
}

let productPromise = null;

function ensureProduct() {
  if (!productPromise) {
    productPromise = (async () => {
      let product = await findProduct();
      if (product) {
        // Self-heal: if a previous run died between creating the product and pricing its seed variant.
        const seed = product.variants.nodes[0];
        if (seed && (!seed.sku || Number(seed.price) === 0)) {
          const amount = parseInt(String(seed.title).replace(/[^0-9]/g, ''), 10);
          if (amount) await configureVariant(product.id, seed.id, amount);
        }
        log('using existing product', product.id);
        return { id: product.id };
      }

      const imageUrl = await sourceImageUrl();
      const seedAmount = cfg.min;
      const d = await gql(
        `mutation($product:ProductCreateInput!, $media:[CreateMediaInput!]){
           productCreate(product:$product, media:$media){
             product{ id variants(first:1){ nodes{ id } } }
             userErrors{ field message } } }`,
        {
          product: {
            title: cfg.title,
            handle: cfg.handle,
            status: 'ACTIVE',
            giftCard: true,
            productType: 'Gift Card',
            tags: [cfg.tag],
            productOptions: [{ name: cfg.optionName, values: [{ name: label(seedAmount) }] }],
            // Keep this helper product out of search-engine results and the sitemap.
            metafields: [{ namespace: 'seo', key: 'hidden', type: 'number_integer', value: '1' }],
          },
          media: imageUrl ? [{ originalSource: imageUrl, mediaContentType: 'IMAGE' }] : [],
        },
      );
      assertNoUserErrors('productCreate', d.productCreate);
      const created = d.productCreate.product;
      await configureVariant(created.id, created.variants.nodes[0].id, seedAmount);

      const pub = await onlineStorePublicationId();
      const p = await gql(
        `mutation($id:ID!, $input:[PublicationInput!]!){
           publishablePublish(id:$id, input:$input){ userErrors{ field message } } }`,
        { id: created.id, input: [{ publicationId: pub }] },
      );
      assertNoUserErrors('publishablePublish', p.publishablePublish);
      log('created product', created.id);
      return { id: created.id };
    })().catch((e) => {
      productPromise = null; // retry on next request
      throw e;
    });
  }
  return productPromise;
}

const inflight = new Map();   // amount -> Promise<variantId>
const recentCreates = [];     // timestamps of newly created amounts

function creationBudgetLeft() {
  const cutoff = Date.now() - 3_600_000;
  while (recentCreates.length && recentCreates[0] < cutoff) recentCreates.shift();
  return recentCreates.length < cfg.maxNewPerHour;
}

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function ensureVariant(amount) {
  const product = await ensureProduct();
  const found = await gql(
    `query($q:String!){ productVariants(first:1, query:$q){ nodes{ id } } }`,
    { q: `sku:${skuFor(amount)} AND product_id:${numericId(product.id)}` },
  );
  if (found.productVariants.nodes[0]) return numericId(found.productVariants.nodes[0].id);

  if (!creationBudgetLeft()) throw new HttpError(429, 'Too many new amounts requested, try again later');
  recentCreates.push(Date.now());

  const d = await gql(
    `mutation($pid:ID!, $v:[ProductVariantsBulkInput!]!){
       productVariantsBulkCreate(productId:$pid, variants:$v){
         productVariants{ id } userErrors{ field message } } }`,
    {
      pid: product.id,
      v: [{
        optionValues: [{ optionName: cfg.optionName, name: label(amount) }],
        price: `${amount}.00`,
        taxable: false,
        inventoryPolicy: 'CONTINUE',
        inventoryItem: { sku: skuFor(amount), tracked: false, requiresShipping: false },
      }],
    },
  );
  assertNoUserErrors('productVariantsBulkCreate', d.productVariantsBulkCreate);
  return numericId(d.productVariantsBulkCreate.productVariants[0].id);
}

function variantForAmount(amount) {
  if (!inflight.has(amount)) {
    inflight.set(amount, ensureVariant(amount).finally(() => inflight.delete(amount)));
  }
  return inflight.get(amount);
}

// ---------------------------------------------------------------------------
// Signature checks
// ---------------------------------------------------------------------------
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

// App proxy: remove `signature`, join repeated keys with commas, sort `key=value`,
// concatenate with NO separator, HMAC-SHA256 (hex) with the app's client secret.
export function validProxySignature(searchParams, secret) {
  const signature = searchParams.get('signature');
  if (!signature || !secret) return false;
  const grouped = new Map();
  for (const [k, v] of searchParams.entries()) {
    if (k === 'signature') continue;
    grouped.set(k, [...(grouped.get(k) || []), v]);
  }
  const message = [...grouped.entries()]
    .map(([k, vs]) => `${k}=${vs.join(',')}`)
    .sort()
    .join('');
  const expected = crypto.createHmac('sha256', secret).update(message).digest('hex');
  return safeEqual(signature, expected);
}

// OAuth callback: sort `key=value`, join with '&', HMAC-SHA256 (hex).
function validOauthHmac(searchParams, secret) {
  const hmac = searchParams.get('hmac');
  if (!hmac) return false;
  const message = [...searchParams.entries()]
    .filter(([k]) => k !== 'hmac')
    .map(([k, v]) => `${k}=${v}`)
    .sort()
    .join('&');
  const expected = crypto.createHmac('sha256', secret).update(message).digest('hex');
  return safeEqual(hmac, expected);
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------
export const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);

app.get('/health', (_req, res) => res.type('text').send('ok'));

app.get('/proxy/amount', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const params = new URL(req.originalUrl, 'http://local').searchParams;

  if (!validProxySignature(params, cfg.clientSecret)) {
    return res.status(401).json({ error: 'invalid_signature' });
  }

  const raw = String(params.get('amount') || '').trim();
  if (!/^\d{1,6}$/.test(raw)) return res.status(400).json({ error: 'invalid_amount' });
  const amount = parseInt(raw, 10);
  if (amount < cfg.min) return res.status(400).json({ error: 'below_minimum', min: cfg.min });
  if (amount > cfg.max) return res.status(400).json({ error: 'above_maximum', max: cfg.max });

  try {
    const variantId = await variantForAmount(amount);
    res.json({ ok: true, amount, variantId });
  } catch (e) {
    log('amount failed', amount, e.message);
    res.status(e.status || 502).json({ error: 'unavailable' });
  }
});

// ----- Optional install fallback (only if the client-credentials grant is refused) -----------
const getCookie = (req, name) =>
  (req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).find(([k]) => k === name)?.[1];

if (cfg.installRoutes) {
  app.get('/install', (req, res) => {
    const shop = String(req.query.shop || cfg.shop);
    if (shop !== cfg.shop) return res.status(400).send('Unknown shop');
    const state = crypto.randomBytes(16).toString('hex');
    res.cookie('se_state', state, { httpOnly: true, secure: true, sameSite: 'lax', maxAge: 600_000 });
    const url = new URL(`https://${shop}/admin/oauth/authorize`);
    url.search = new URLSearchParams({
      client_id: cfg.clientId,
      scope: cfg.scopes,
      redirect_uri: `${cfg.appUrl}/auth/callback`,
      state,
    }).toString();
    res.redirect(url.toString());
  });

  app.get('/auth/callback', async (req, res) => {
    const p = new URL(req.originalUrl, 'http://local').searchParams;
    if (p.get('shop') !== cfg.shop) return res.status(400).send('Unknown shop');
    if (!p.get('state') || p.get('state') !== getCookie(req, 'se_state')) return res.status(400).send('Bad state');
    if (!validOauthHmac(p, cfg.clientSecret)) return res.status(401).send('Bad signature');
    const r = await fetch(`https://${cfg.shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: cfg.clientId, client_secret: cfg.clientSecret, code: p.get('code') }),
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok || !body.access_token) return res.status(502).send('Token exchange failed');
    res.set('Cache-Control', 'no-store').type('html').send(
      `<h2>Installed</h2><p>Add this to your server's environment, then redeploy, then set ` +
      `<code>ENABLE_INSTALL_ROUTES=false</code>:</p><pre>SHOPIFY_ACCESS_TOKEN=${body.access_token}</pre>`,
    );
  });
}

if (process.argv[1] && import.meta.url === new URL(`file://${process.argv[1]}`).href) {
  const missing = ['shop', 'clientSecret'].filter((k) => !cfg[k]);
  if (missing.length) { console.error('Missing env:', missing.join(', ')); process.exit(1); }
  if (!cfg.staticToken && !cfg.clientId) { console.error('Missing SHOPIFY_CLIENT_ID'); process.exit(1); }
  app.listen(int(env.PORT, 3000), () => log('listening on', env.PORT || 3000));
}
